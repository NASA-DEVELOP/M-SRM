"""
This is a quick script using dnppy for use in downloading GPM data
and converting it from HDF5 to geotiff.
"""

__author__ = 'Jwely'

from dnppy import download, convert, tsa, raster
from datetime import datetime

# ------------------------------------------------------------------------
# user input here
# ------------------------------------------------------------------------
dldir = r"GPM\hdf"                      # directory to download IMERGE data
shapefile = r"chile_box\CHL_box.shp"    # path to clipping geometry
start = datetime(2015, 4, 1)            # starting (year, month, day)
end   = datetime(2015, 4, 7)            # ending (year, month, day)
# ------------------------------------------------------------------------

# download GPM IMERG data
dlist = download.fetch_GPM_IMERG(start, end, "GPM/gis", product = "gis")

# clip the data to chile shape file
cliplist = raster.clip_to_shape(dlist, shapefile)
