"""
This is a quick script using dnppy for use in downloading GPM data
and converting it from HDF5 to geotiff.
"""

__author__ = 'Jwely'

from dnppy import download, convert, tsa, raster
from datetime import datetime

# ------------------------------------------------------------------------
# user input here
# ------------------------------------------------------------------------
dldir = r"GPM\hdf"                      # directory to download IMERGE data
tifdir = r"GPM\tif"                     # directory to extract tifs into
daydir = r"GPM\daily_mean"              # directory to place daily averaged tiffs
shapefile = r"chile_box\CHL_box.shp"    # path to clipping geometry
start = datetime(2015, 4, 1)            # starting (year, month, day)
end   = datetime(2015, 4, 7)            # ending (year, month, day)
# ------------------------------------------------------------------------

# download GPM IMERG data
dlist = download.fetch_GPM_IMERG(start, end, outdir = dldir, product = "late")

# extract HDFS to GeoTiffs
tiflist = convert.extract_GPM_IMERG(dlist, layer_indexs = 5, resolution = "0.1")

# clip the data to chile shape file
cliplist = raster.clip_to_shape(tiflist, shapefile)

# create daily totals with rast_series object
fmt = "%Y%m%d-S%H%M%S"
fmt_unmask = range(23,39)
rs = tsa.rast_series()
rs.from_rastlist(cliplist, fmt, fmt_unmask)
rs.make_subsets("%d", overlap_width = 0)
rs.series_stats(daydir, saves = ["AVG"])
